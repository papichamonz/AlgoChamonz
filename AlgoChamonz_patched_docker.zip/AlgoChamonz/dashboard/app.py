#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ALGO — Stock Dashboard (Streamlit)
- Toolbar no topo (Símbolo e Intervalo) — indicadores saem da toolbar
- Plotly candlesticks OU TradingView Lightweight Charts (toggle)
- Indicadores: SMA20, SMA50, RSI(14), MACD, Bollinger(20,2)
- Agora: widget flutuante **dentro do gráfico LWC** para ligar/desligar overlays
- Cache no download
"""

import os, sys, json
import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
import streamlit.components.v1 as components

APP_DIR = os.path.dirname(__file__)
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from phase3_consolidator import (
    download_data, compute_indicators, fetch_fundamentals, fetch_news_summary,
    build_phase3_payload, format_structured_report, generate_report_with_gpt
)

st.set_page_config(page_title="ALGO – Stock Dashboard", layout="wide")
st.title("📈 ALGO — Stock Dashboard")

# -------- Toolbar (sem indicadores aqui) --------
tb1, tb2, tb3 = st.columns([2,1,1])
with tb1:
    ticker = st.text_input("Símbolo", value=st.session_state.get("sym", "AAPL"), key="sym")
with tb2:
    interval = st.selectbox("Intervalo", ["5m","15m","1h","1d","1wk"], index=3, key="intv")
with tb3:
    period = st.selectbox("Período", ["1mo","3mo","6mo","12mo","2y","5y","max"], index=2, key="per")

# ---------------- Sidebar ----------------
with st.sidebar:
    st.header("Opções")
    news_query = st.text_input("Query de notícias (opcional)", value=f"{ticker} OR {ticker}")
    news_limit = st.slider("Limite de notícias", 5, 30, 12)
    lookback = st.slider("Lookback notícias (dias)", 1, 30, 7)
    news_lang = st.text_input("Idioma Google News (hl)", value="pt-PT")
    openai_model = st.text_input("Modelo GPT (opcional)", value="")
    st.markdown("---")
    use_lwc = st.checkbox(
        "Usar TradingView Lightweight Charts",
        value=True,
        help="Se o servidor não tiver internet, desativa para usar Plotly."
    )
    # Visibilidade de painéis secundários (RSI/MACD) fora do canvas
    show_rsi = st.checkbox("Mostrar RSI(14)", value=True)
    show_macd = st.checkbox("Mostrar MACD", value=True)
    show_candles = st.checkbox("Mostrar velas (no gráfico Plotly)", value=True)
    run_btn = st.button("Analisar", type="primary")

# ---------------- Indicadores auxiliares ----------------
def add_bollinger(df: pd.DataFrame, length: int = 20, mult: float = 2.0) -> pd.DataFrame:
    close = df["Close"].astype(float)
    mid = close.rolling(length).mean()
    std = close.rolling(length).std()
    df["BB_MID"] = mid
    df["BB_UP"]  = mid + mult*std
    df["BB_DN"]  = mid - mult*std
    return df

@st.cache_data(show_spinner=False)
def cached_download_data(ticker: str, period: str, interval: str) -> pd.DataFrame:
    return download_data(ticker, period, interval)

# ---------------- Gráficos ----------------
def plot_candles_plotly(df: pd.DataFrame, supports=None, resistances=None, show_candles: bool=True):
    fig = go.Figure()
    x = pd.to_datetime(df.index).to_pydatetime()
    if show_candles:
        fig.add_trace(go.Candlestick(
            x=x, open=df['Open'].astype(float), high=df['High'].astype(float),
            low=df['Low'].astype(float), close=df['Close'].astype(float), name="OHLC",
            increasing=dict(line=dict(color="rgb(46,204,113)", width=2), fillcolor="rgba(46,204,113,0.45)"),
            decreasing=dict(line=dict(color="rgb(231,76,60)", width=2), fillcolor="rgba(231,76,60,0.45)"),
            whiskerwidth=0.7, showlegend=True
        ))
        fig.add_trace(go.Scatter(x=x, y=df['Close'], name='Close', mode='lines', opacity=0.35))
    else:
        fig.add_trace(go.Scatter(x=x, y=df['Close'], name='Close', mode='lines'))

    # SMAs sempre disponíveis no Plotly (não há widget no canvas)
    if 'SMA20' in df: fig.add_trace(go.Scatter(x=x, y=df['SMA20'], name='SMA20', mode='lines'))
    if 'SMA50' in df: fig.add_trace(go.Scatter(x=x, y=df['SMA50'], name='SMA50', mode='lines'))
    if {'BB_UP','BB_MID','BB_DN'}.issubset(df.columns):
        fig.add_trace(go.Scatter(x=x, y=df['BB_UP'],  name='BB Upper', mode='lines', opacity=0.6))
        fig.add_trace(go.Scatter(x=x, y=df['BB_MID'], name='BB Mid',   mode='lines', opacity=0.4))
        fig.add_trace(go.Scatter(x=x, y=df['BB_DN'],  name='BB Lower', mode='lines', opacity=0.6))

    shapes = []
    if len(x) > 0:
        x0, x1 = x[0], x[-1]
        for y in (supports or []):
            shapes.append(dict(type="line", xref="x", yref="y", x0=x0, x1=x1, y0=y, y1=y,
                               line=dict(width=1, dash="dot", color="rgba(200,200,200,0.6)"), layer="below"))
        for y in (resistances or []):
            shapes.append(dict(type="line", xref="x", yref="y", x0=x0, x1=x1, y0=y, y1=y,
                               line=dict(width=1, dash="dash", color="rgba(255,255,255,0.5)"), layer="below"))
    lo = float(np.nanmin(df['Low'].astype(float))); hi = float(np.nanmax(df['High'].astype(float)))
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        lo, hi = float(df['Close'].iloc[-1]) - 1.0, float(df['Close'].iloc[-1]) + 1.0
    pad = max((hi - lo) * 0.1, 1e-6)
    fig.update_layout(height=520, xaxis_rangeslider_visible=False, hovermode="x unified",
                      xaxis=dict(type="date"), yaxis=dict(range=[lo-pad, hi+pad], autorange=False),
                      shapes=shapes, margin=dict(t=40, b=10, l=10, r=10), legend=dict(orientation="v"))
    return fig

def render_lightweight_chart(df: pd.DataFrame, supports=None, resistances=None, show_sr: bool=True):
    base_cols = ["Open","High","Low","Close"]
    for c in base_cols:
        if c not in df.columns:
            st.error(f"Coluna em falta para LWC: {c}"); return
    df2 = df[base_cols].apply(pd.to_numeric, errors="coerce").dropna().copy()
    if df2.empty:
        st.warning("Sem dados OHLC válidos para desenhar."); return

    # Série de dados
    ts = (pd.to_datetime(df2.index).astype("int64") // 10**9).astype(int).tolist()
    data = [{"time": int(t), "open": float(o), "high": float(h), "low": float(l), "close": float(c)}
            for t, o, h, l, c in zip(ts, df2.Open, df2.High, df2.Low, df2.Close)]

    def _line(series: pd.Series):
        s = pd.to_numeric(series, errors="coerce").reindex(df2.index).dropna()
        ts_s = (pd.to_datetime(s.index).astype("int64") // 10**9).astype(int).tolist()
        return [{"time": int(t), "value": float(v)} for t, v in zip(ts_s, s.to_numpy().tolist())]

    sma20 = _line(df["SMA20"]) if "SMA20" in df.columns else []
    sma50 = _line(df["SMA50"]) if "SMA50" in df.columns else []
    bb_up = bb_mid = bb_dn = []
    if {"BB_UP","BB_MID","BB_DN"}.issubset(df.columns):
        bb_up  = _line(df["BB_UP"])
        bb_mid = _line(df["BB_MID"])
        bb_dn  = _line(df["BB_DN"])

    lo, hi = float(np.nanmin(df2["Low"])), float(np.nanmax(df2["High"]))
    def _flt(levels):
        out=[]; 
        for x in (levels or []):
            try:
                xv=float(x)
                if np.isfinite(xv) and (lo*0.95)<=xv<=(hi*1.05): out.append(xv)
            except Exception: pass
        return out
    supports = _flt(supports); resistances = _flt(resistances)

    payload = {
        "data": data, "sma20": sma20, "sma50": sma50,
        "bb_up": bb_up, "bb_mid": bb_mid, "bb_dn": bb_dn,
        "supports": supports, "resistances": resistances, "show_sr": bool(show_sr)
    }

    html = f"""
    <style>
      .algo-widget {{
        position:absolute; top:12px; left:12px; z-index:10;
        background: rgba(0,0,0,0.55); backdrop-filter: blur(2px);
        padding: 10px 12px; border-radius: 10px; font: 12px/1.3 system-ui, sans-serif; color:#eee;
      }}
      .algo-widget label {{ display:block; margin:4px 0; cursor:pointer; }}
      .algo-wrap {{ position: relative; height:540px; width:100%; }}
      .algo-widget .title {{ font-weight:600; margin-bottom:6px; opacity:.9 }}
    </style>
    <div class="algo-wrap">
      <div class="algo-widget">
        <div class="title">Indicadores</div>
        <label><input type="checkbox" id="ck_sma20" checked> SMA20</label>
        <label><input type="checkbox" id="ck_sma50" checked> SMA50</label>
        <label><input type="checkbox" id="ck_boll" {( 'checked' if (bb_up and bb_dn) else '' )}> Bollinger</label>
        <label><input type="checkbox" id="ck_sr" {( 'checked' if show_sr else '' )}> Suporte/Resistência</label>
      </div>
      <div id="tvwrap" style="height:100%;width:100%"></div>
    </div>
    <script src="https://unpkg.com/lightweight-charts@4.1.0/dist/lightweight-charts.standalone.production.js"></script>
    <script>
      const P = {json.dumps(payload)};
      const el = document.getElementById('tvwrap');
      const chart = LightweightCharts.createChart(el, {{
        layout: {{ background: {{ type: 'solid', color: '#111' }}, textColor: '#DDD' }},
        grid: {{ vertLines: {{ color: 'rgba(255,255,255,0.06)' }},
                 horzLines: {{ color: 'rgba(255,255,255,0.06)' }} }},
        rightPriceScale: {{ borderVisible: false, scaleMargins: {{ top: 0.10, bottom: 0.20 }} }},
        timeScale: {{ borderVisible: false }},
        autoSize: true
      }});

      const cs = chart.addCandlestickSeries({{
        upColor: '#2ecc71', downColor: '#e74c3c',
        borderUpColor: '#2ecc71', borderDownColor: '#e74c3c',
        wickUpColor: '#2ecc71', wickDownColor: '#e74c3c'
      }});
      cs.setData(P.data);

      // Overlays e controlos
      let l_sma20 = null, l_sma50 = null, l_bb_up = null, l_bb_mid = null, l_bb_dn = null;
      function drawSMA20(on) {{
        if (on && P.sma20 && P.sma20.length) {{ l_sma20 = l_sma20 || chart.addLineSeries({{ lineWidth:2 }}); l_sma20.setData(P.sma20); }}
        else if (l_sma20) {{ l_sma20.setData([]); }}
      }}
      function drawSMA50(on) {{
        if (on && P.sma50 && P.sma50.length) {{ l_sma50 = l_sma50 || chart.addLineSeries({{ lineWidth:2 }}); l_sma50.setData(P.sma50); }}
        else if (l_sma50) {{ l_sma50.setData([]); }}
      }}
      function drawBoll(on) {{
        if (on && P.bb_up && P.bb_up.length) {{
          l_bb_up  = l_bb_up  || chart.addLineSeries({{ lineWidth:1 }});
          l_bb_mid = l_bb_mid || chart.addLineSeries({{ lineWidth:1, lineStyle: LightweightCharts.LineStyle.Dotted }});
          l_bb_dn  = l_bb_dn  || chart.addLineSeries({{ lineWidth:1 }});
          l_bb_up.setData(P.bb_up); l_bb_mid.setData(P.bb_mid||[]); l_bb_dn.setData(P.bb_dn);
        }} else {{
          if (l_bb_up) l_bb_up.setData([]);
          if (l_bb_mid) l_bb_mid.setData([]);
          if (l_bb_dn) l_bb_dn.setData([]);
        }}
      }}
      // Suportes/Resistências
      let priceLines = [];
      function drawSR(on) {{
        priceLines.forEach(pl => cs.removePriceLine(pl));
        priceLines = [];
        if (on) {{
          (P.supports||[]).forEach(v => priceLines.push(cs.createPriceLine({{
            price:v, color:'#888', lineStyle:LightweightCharts.LineStyle.Dotted, lineWidth:1, title:'S'
          }})));
          (P.resistances||[]).forEach(v => priceLines.push(cs.createPriceLine({{
            price:v, color:'#bbb', lineStyle:LightweightCharts.LineStyle.Dashed, lineWidth:1, title:'R'
          }})));
        }}
      }}

      // Estado inicial (checked)
      drawSMA20(true); drawSMA50(true); drawBoll({ 'true' if (bb_up and bb_dn) else 'false' }); drawSR({ 'true' if show_sr else 'false' });

      // Listeners
      const ck20 = document.getElementById('ck_sma20');
      const ck50 = document.getElementById('ck_sma50');
      const ckb  = document.getElementById('ck_boll');
      const cksr = document.getElementById('ck_sr');
      ck20.addEventListener('change', e => drawSMA20(e.target.checked));
      ck50.addEventListener('change', e => drawSMA50(e.target.checked));
      ckb.addEventListener('change',  e => drawBoll(e.target.checked));
      cksr.addEventListener('change', e => drawSR(e.target.checked));

      chart.timeScale().fitContent();
    </script>
    """
    components.html(html, height=560, scrolling=False)

def plot_rsi(df: pd.DataFrame):
    if "RSI14" not in df.columns: return None
    x = pd.to_datetime(df.index).to_pydatetime()
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=x, y=df['RSI14'], name="RSI(14)", mode='lines'))
    fig.add_hrect(y0=30, y1=70, fillcolor="rgba(200,200,200,0.15)", line_width=0)
    fig.update_yaxes(range=[0,100])
    fig.update_layout(height=180, margin=dict(t=10, b=10, l=10, r=10))
    return fig

def plot_macd(df: pd.DataFrame):
    if not {'MACD','MACD_SIGNAL','MACD_HIST'}.issubset(df.columns): return None
    x = pd.to_datetime(df.index).to_pydatetime()
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=x, y=df['MACD'], name="MACD", mode='lines'))
    fig.add_trace(go.Scatter(x=x, y=df['MACD_SIGNAL'], name="Sinal", mode='lines'))
    fig.add_trace(go.Bar(x=x, y=df['MACD_HIST'], name="Histograma", opacity=0.4))
    fig.update_layout(height=220, margin=dict(t=10, b=10, l=10, r=10))
    return fig

# ---------------- Main ----------------
if run_btn:
    try:
        df = cached_download_data(ticker, period, interval)
        df = compute_indicators(df)
        # Bollinger sempre calculado para permitir toggle no widget
        df = add_bollinger(df)

        fundamentals = fetch_fundamentals(ticker)
        news_summary = fetch_news_summary(news_query, news_limit, lookback, news_lang) if news_query else                        type("Obj", (), {"avg_sentiment_score": None, "counts": {"positive":0,"neutral":0,"negative":0}})()

        payload = build_phase3_payload(ticker, df, news_summary, fundamentals)
        tech = payload["technical"]

        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Fecho", f"{tech['close']:.2f}")
        rsi_val = tech.get("rsi14")
        col2.metric("RSI(14)", "—" if rsi_val is None or (isinstance(rsi_val,float) and np.isnan(rsi_val)) else f"{rsi_val:.1f}")
        col3.metric("Tendência", tech.get("trend","—"))
        macd_hist = tech.get("macd_hist")
        col4.metric("MACD Hist", "—" if macd_hist is None or (isinstance(macd_hist,float) and np.isnan(macd_hist)) else f"{macd_hist:.2f}")

        st.subheader("Gráfico")
        sr = tech.get("support_resistance", {})
        supports = sr.get("supports", []); resistances = sr.get("resistances", [])
        if use_lwc:
            render_lightweight_chart(df, supports, resistances, show_sr=True)
        else:
            fig_c = plot_candles_plotly(df, supports, resistances, show_candles)
            st.plotly_chart(fig_c, use_container_width=True)

        if show_rsi:
            fr = plot_rsi(df); 
            if fr: st.plotly_chart(fr, use_container_width=True)
        if show_macd:
            fm = plot_macd(df); 
            if fm: st.plotly_chart(fm, use_container_width=True)

        st.subheader("Relatório Estruturado")
        md = format_structured_report(payload, locale="pt-PT")
        st.markdown(md)

        st.subheader("Downloads")
        st.download_button("Baixar JSON", data=json.dumps(payload, ensure_ascii=False, indent=2),
                           file_name=f"{ticker}_{interval}_phase3.json", mime="application/json")
        st.download_button("Baixar Relatório (MD)", data=md, file_name=f"{ticker}_{interval}_structured.md",
                           mime="text/markdown")

        if openai_model.strip():
            st.info("Para relatório GPT, exporte OPENAI_API_KEY no ambiente antes de lançar o Streamlit.")
            try:
                gpt_md = generate_report_with_gpt(payload, openai_model.strip())
                st.subheader("Relatório (GPT)"); st.markdown(gpt_md)
            except Exception as e:
                st.error(f"Falha ao gerar relatório GPT: {e}")
    except Exception as e:
        st.exception(e)
else:
    st.info("Defina símbolo/intervalo no topo e clique **Analisar**. Indicadores agora são controlados por um widget dentro do gráfico.")
