#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mini-TheAlgo – Fase 1 Completo
- Preços via Yahoo (yfinance)
- Indicadores: RSI(14), SMA20, SMA50
- Sinais básicos
- Fundamentos (trailingPE, forwardPE, etc.)
- CSV com indicadores
- Gráfico: Candlesticks + SMA20/50 + RSI (mplfinance)
- Suporte a headless: salva PNG automaticamente se não houver display
"""

import argparse
import json
from pathlib import Path
from typing import Optional
import os
import matplotlib
import pandas as pd
import yfinance as yf
import ta

# ----------------- Helpers ----------------- #
def _is_headless() -> bool:
    backend = matplotlib.get_backend().lower()
    return (os.environ.get("DISPLAY") in (None, "")) or ("agg" in backend)

# ----------------- Preços & Indicadores ----------------- #
def download_data(ticker: str, period: str, interval: str) -> pd.DataFrame:
    print(f"📥 Baixando {ticker} ({period}, {interval})...")
    df = yf.download(ticker, period=period, interval=interval,
                     progress=False, group_by="column")
    if df.empty:
        raise SystemExit("❌ Nenhum dado retornado. Verifique ticker/period/interval.")

    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [tup[0] if tup[0] else (tup[1] or "") for tup in df.columns]

    return df.dropna(how="all")


def _get_close_series(df: pd.DataFrame) -> pd.Series:
    candidates = [c for c in ["Close", "Adj Close"] if c in df.columns]
    if not candidates:
        matches = [c for c in df.columns if "close" in c.lower()]
        if not matches:
            raise ValueError(f"Sem coluna de fechamento nas colunas: {list(df.columns)}")
        candidates = [matches[0]]
    close = df[candidates[0]]
    if isinstance(close, pd.DataFrame):
        close = close.iloc[:, 0]
    return pd.to_numeric(close.squeeze(), errors="coerce")


def compute_indicators(df: pd.DataFrame) -> pd.DataFrame:
    close = _get_close_series(df)
    df = df.copy()
    df["Close"] = close
    df["SMA20"] = close.rolling(window=20).mean()
    df["SMA50"] = close.rolling(window=50).mean()
    df["RSI14"] = ta.momentum.RSIIndicator(close, window=14).rsi()
    return df


def generate_signals(df: pd.DataFrame) -> list:
    last = df.iloc[-1]
    rsi = float(last["RSI14"])
    sma20 = float(last["SMA20"])
    sma50 = float(last["SMA50"])
    signals = []
    if rsi < 30:
        signals.append("📈 COMPRA (RSI < 30: sobrevendido)")
    elif rsi > 70:
        signals.append("📉 VENDA (RSI > 70: sobrecomprado)")
    else:
        signals.append("➖ NEUTRO (RSI entre 30 e 70)")
    if sma20 > sma50:
        signals.append("📈 Tendência de alta (SMA20 > SMA50)")
    elif sma20 < sma50:
        signals.append("📉 Tendência de baixa (SMA20 < SMA50)")
    else:
        signals.append("➖ Sem tendência clara (SMA20 ≈ SMA50)")
    return signals


def save_to_csv(df: pd.DataFrame, ticker: str, interval: str):
    fname = f"indicators_{ticker}_{interval}.csv"
    df.to_csv(fname)
    print(f"✅ Arquivo salvo: {fname}")

# ----------------- Fundamentos ----------------- #
FUND_KEYS = [
    "trailingPE", "forwardPE", "pegRatio", "priceToBook",
    "dividendYield", "marketCap", "enterpriseValue",
    "enterpriseToEbitda",
    "profitMargins", "returnOnEquity",
    "revenueGrowth", "earningsGrowth",
    "fiftyTwoWeekLow", "fiftyTwoWeekHigh",
    "longName", "sector", "industry"
]

def _safe_float(x):
    try:
        return float(x)
    except Exception:
        return None

def fetch_fundamentals(ticker: str) -> dict:
    tkr = yf.Ticker(ticker)
    try:
        info = tkr.get_info()
    except Exception:
        try:
            info = tkr.info
        except Exception:
            info = {}

    data = {}
    for k in FUND_KEYS:
        v = info.get(k)
        if k not in ("longName", "sector", "industry") and v is not None:
            v = _safe_float(v)
        data[k] = v

    try:
        fi = tkr.fast_info
        data.setdefault("marketCap", _safe_float(getattr(fi, "market_cap", None)))
        data.setdefault("fiftyTwoWeekLow", _safe_float(getattr(fi, "year_low", None)))
        data.setdefault("fiftyTwoWeekHigh", _safe_float(getattr(fi, "year_high", None)))
    except Exception:
        pass

    if data.get("dividendYield") is not None:
        dy = data["dividendYield"]
        data["dividendYieldPct"] = round(dy * 100, 2) if dy < 1 else round(dy, 2)
    return data

def save_fundamentals_json(fund: dict, ticker: str):
    fname = f"fundamentals_{ticker}.json"
    Path(fname).write_text(json.dumps(fund, indent=2, ensure_ascii=False))
    print(f"✅ Arquivo salvo: {fname}")

# ----------------- Gráficos ----------------- #
def _assemble_ohlc_for_mpf(df: pd.DataFrame) -> pd.DataFrame:
    def pick_col(name: str) -> Optional[pd.Series]:
        if name in df.columns:
            return df[name]
        matches = [c for c in df.columns if name.lower() in c.lower()]
        return df[matches[0]] if matches else None

    out = pd.DataFrame(index=df.index)
    for key in ["Open", "High", "Low", "Close"]:
        s = pick_col(key)
        if s is not None:
            out[key] = pd.to_numeric(s, errors="coerce")

    vol = pick_col("Volume")
    if vol is not None:
        out["Volume"] = pd.to_numeric(vol, errors="coerce")

    for ind in ["SMA20", "SMA50", "RSI14"]:
        if ind in df.columns:
            out[ind] = pd.to_numeric(df[ind], errors="coerce")

    out.index.name = "Date"
    return out.dropna(subset=["Open", "High", "Low", "Close"], how="any")

def plot_charts_mpf(df: pd.DataFrame, ticker: str, save_png: str | None = None, style: str = "yahoo"):
    import mplfinance as mpf
    dfp = _assemble_ohlc_for_mpf(df)

    apds = []
    if "SMA20" in dfp.columns:
        apds.append(mpf.make_addplot(dfp["SMA20"], width=1))
    if "SMA50" in dfp.columns:
        apds.append(mpf.make_addplot(dfp["SMA50"], width=1))
    if "RSI14" in dfp.columns:
        apds.append(mpf.make_addplot(dfp["RSI14"], panel=1, ylabel="RSI(14)"))

    if _is_headless() and not save_png:
        save_png = f"chart_{ticker}.png"

    kwargs = dict(
        type="candle",
        addplot=apds if apds else None,
        volume=("Volume" in dfp.columns),
        style=style,
        title=f"{ticker} — Candles + SMA20/50 + RSI",
        panel_ratios=(3, 1),
        figratio=(16, 9),
        tight_layout=True,
        returnfig=True,
    )
    if save_png:
        kwargs["savefig"] = save_png

    fig, axlist = mpf.plot(dfp, **kwargs)
    if _is_headless():
        import matplotlib.pyplot as plt
        plt.close(fig)
        if save_png:
            print(f"🖼️ Gráfico salvo: {save_png}")

# --- NOVO: padrões de candles ---
def _candles_talib(df: pd.DataFrame):
    try:
        import talib
    except Exception:
        return None  # força fallback
    o, h, l, c = [df[col].astype(float).values for col in ["Open", "High", "Low", "Close"]]

    patterns = {
        "CDLENGULFING": talib.CDLENGULFING(o, h, l, c),
        "CDLHAMMER": talib.CDLHAMMER(o, h, l, c),
        "CDLSHOOTINGSTAR": talib.CDLSHOOTINGSTAR(o, h, l, c),
        "CDLDOJI": talib.CDLDOJI(o, h, l, c),
        "CDLMORNINGSTAR": talib.CDLMORNINGSTAR(o, h, l, c),
        "CDLEVENINGSTAR": talib.CDLEVENINGSTAR(o, h, l, c),
        "CDLHARAMI": talib.CDLHARAMI(o, h, l, c),
        "CDLPIERCING": talib.CDLPIERCING(o, h, l, c),
        "CDLDARKCLOUDCOVER": talib.CDLDARKCLOUDCOVER(o, h, l, c),
    }
    # Valor típico TA-Lib: 100/200 (bullish), -100/-200 (bearish), 0 (none)
    last_idx = -1
    detected = {}
    for name, series in patterns.items():
        val = int(series[last_idx])
        if val != 0:
            detected[name] = val
    return detected

def _is_doji(o, h, l, c, tol=0.0015):
    body = abs(c - o)
    rng = max(h, c, o) - min(l, c, o)
    if rng == 0:
        return False
    return (body / rng) <= tol

def _is_bullish_engulfing(prev_o, prev_c, o, c):
    return (prev_c < prev_o) and (c > o) and (c >= prev_o) and (o <= prev_c)

def _is_bearish_engulfing(prev_o, prev_c, o, c):
    return (prev_c > prev_o) and (c < o) and (c <= prev_o) and (o >= prev_c)

def _is_hammer(o, h, l, c):
    body = abs(c - o)
    lower_shadow = (min(c, o) - l)
    upper_shadow = (h - max(c, o))
    rng = h - l if (h - l) != 0 else 1e-9
    # martelo: sombra inferior longa, corpo pequeno, pouca sombra superior
    return (lower_shadow / rng > 0.5) and (body / rng < 0.3) and (upper_shadow / rng < 0.2)

def _candles_pandas(df: pd.DataFrame):
    if len(df) < 2:
        return {}
    last = df.iloc[-1]
    prev = df.iloc[-2]
    o, h, l, c = float(last.Open), float(last.High), float(last.Low), float(last.Close)
    po, pc = float(prev.Open), float(prev.Close)

    detected = {}
    if _is_doji(o, h, l, c):
        detected["DOJI"] = 1
    if _is_hammer(o, h, l, c):
        detected["HAMMER"] = 1
    if _is_bullish_engulfing(po, pc, o, c):
        detected["ENGULFING_BULL"] = 1
    if _is_bearish_engulfing(po, pc, o, c):
        detected["ENGULFING_BEAR"] = -1
    return detected

def detect_candles(df: pd.DataFrame) -> dict:
    """
    Tenta TA-Lib; se indisponível, usa regras em pandas.
    Retorna dict de {padrao: força}, só para o último candle.
    """
    d = _candles_talib(df)
    if d is None:
        d = _candles_pandas(df)
    return d

# --- Exemplo de uso dentro do fluxo ---
def build_phase3_payload(ticker: str, df: pd.DataFrame, news_summary: dict, fundamentals: dict) -> dict:
    last = df.iloc[-1]
    tech = {
        "close": float(last["Close"]),
        "rsi14": float(last.get("RSI14", float("nan"))),
        "sma20": float(last.get("SMA20", float("nan"))),
        "sma50": float(last.get("SMA50", float("nan"))),
        "trend": "alta" if last.get("SMA20", 0) > last.get("SMA50", 0) else "baixa",
        "candles": detect_candles(df),  # << padrões aqui
    }
    payload = {
        "ticker": ticker,
        "technical": tech,
        "fundamental": fundamentals,   # ex.: {"pe": 22.1, "dy": 0.018, "epsYoY": 0.31}
        "news_sentiment": {
            "avg_score": news_summary.get("avg_sentiment_score"),
            "counts": news_summary.get("counts"),
        },
        "generated_at": pd.Timestamp.utcnow().isoformat(),
    }
    return payload

# ----------------- Main ----------------- #
def main():
    parser = argparse.ArgumentParser(description="Mini-TheAlgo • Fase 1 – Técnico + Fundamentos + Candles")
    parser.add_argument("--ticker", required=True)
    parser.add_argument("--period", default="6mo")
    parser.add_argument("--interval", default="1d")
    parser.add_argument("--fundamentals", action="store_true")
    parser.add_argument("--plot", action="store_true")
    parser.add_argument("--save-png", type=str, default=None)
    parser.add_argument("--style", type=str, default="yahoo")
    args = parser.parse_args()

    df = download_data(args.ticker, args.period, args.interval)
    df = compute_indicators(df)
    signals = generate_signals(df)

    last = df.iloc[-1]
    print("\n—— Resultado Técnico ——")
    print(f"Ticker: {args.ticker}")
    print(f"Close: {last['Close']:.2f} | RSI14: {last['RSI14']:.2f} | SMA20: {last['SMA20']:.2f} | SMA50: {last['SMA50']:.2f}")
    print("Sinais:")
    for s in signals: print(" -", s)

    save_to_csv(df, args.ticker, args.interval)

    if args.fundamentals:
        fund = fetch_fundamentals(args.ticker)
        print("\n—— Fundamentos ——")
        for k, v in fund.items():
            if v is None: continue
            if k == "dividendYield" and "dividendYieldPct" in fund:
                print(f"{k}: {v} (~{fund['dividendYieldPct']}%)")
            else:
                print(f"{k}: {v}")
        save_fundamentals_json(fund, args.ticker)

    if args.plot:
        plot_charts_mpf(df, args.ticker, save_png=args.save_png, style=args.style)

if __name__ == "__main__":
    main()
