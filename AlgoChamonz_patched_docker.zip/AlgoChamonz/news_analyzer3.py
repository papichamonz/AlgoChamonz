#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
News Sentiment Analyzer (FinBERT -> VADER fallback) com:
- Resolução robusta de links do Google News (consent, gstatic, etc.)
- Tentativa automática de arquivo via archive.ph quando há paywall/consent
- Limpeza de boilerplate (cookies/GDPR)
- Média ponderada por fonte + recência + tamanho do texto
- Idioma do feed configurável (--lang), ex.: pt-PT ou en-US
"""

import argparse
import dataclasses
import json
import math
import re
import time
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
from urllib.parse import urlparse, parse_qs, unquote, quote

import requests
import feedparser
from bs4 import BeautifulSoup
from lxml import html as lxml_html
from readability import Document
import tldextract
from tqdm import tqdm

# --------------- Sessão HTTP com retries leves ----------------
UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": UA, "Accept-Language": "en,pt;q=0.8"})

try:
    # retries opcionais (não é crítico se falhar)
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
    retries = Retry(total=3, backoff_factor=0.5, status_forcelist=(429, 500, 502, 503, 504))
    adapter = HTTPAdapter(max_retries=retries)
    SESSION.mount("http://", adapter)
    SESSION.mount("https://", adapter)
except Exception:
    pass

# -------- Sentiment backends (FinBERT -> fallback VADER) ----------
FINBERT = None
VADER = None

def _try_load_finbert():
    global FINBERT
    if FINBERT is not None:
        return FINBERT
    try:
        from transformers import AutoTokenizer, AutoModelForSequenceClassification, TextClassificationPipeline
        model_name = "ProsusAI/finbert"
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForSequenceClassification.from_pretrained(model_name)
        FINBERT = TextClassificationPipeline(model=model, tokenizer=tokenizer, top_k=None, truncation=True)
    except Exception:
        FINBERT = None
    return FINBERT

def _try_load_vader():
    global VADER
    if VADER is not None:
        return VADER
    try:
        import nltk
        from nltk.sentiment import SentimentIntensityAnalyzer
        try:
            nltk.data.find("sentiment/vader_lexicon.zip")
        except LookupError:
            nltk.download("vader_lexicon", quiet=True)
        VADER = SentimentIntensityAnalyzer()
    except Exception:
        VADER = None
    return VADER

def score_sentiment(text: str) -> Dict[str, Any]:
    """
    Retorna:
      dict(score in [-1,1], label in {positive,neutral,negative}, confidence [0,1], engine {finbert|vader|none})
    """
    text = (text or "").strip()
    if not text:
        return {"score": 0.0, "label": "neutral", "confidence": 0.0, "engine": "none"}

    # FinBERT preferido (melhor em contexto financeiro)
    fb = _try_load_finbert()
    if fb is not None:
        try:
            out = fb(text[:4000])
            # Alguns transformers devolvem list[ list[dict] ] e outros list[dict]
            preds = out[0] if (isinstance(out, list) and len(out) > 0 and isinstance(out[0], list)) else out
            by_label = {}
            for d in preds:
                lab = d.get("label", "").lower()
                sc = float(d.get("score", 0.0))
                by_label[lab] = sc
            pos = by_label.get("positive", 0.0)
            neu = by_label.get("neutral", 0.0)
            neg = by_label.get("negative", 0.0)
            score = pos - neg  # esperado em [-1,1]
            label, conf = max(by_label.items(), key=lambda kv: kv[1]) if by_label else ("neutral", 0.0)
            return {"score": score, "label": label, "confidence": conf, "engine": "finbert"}
        except Exception:
            pass

    # Fallback VADER
    vd = _try_load_vader()
    if vd is not None:
        try:
            res = vd.polarity_scores(text[:8000])   # {'neg':..,'neu':..,'pos':..,'compound':..}
            comp = float(res.get("compound", 0.0))  # [-1,1]
            if comp >= 0.05:
                label, conf = "positive", abs(comp)
            elif comp <= -0.05:
                label, conf = "negative", abs(comp)
            else:
                label, conf = "neutral", 1 - abs(comp)
            return {"score": comp, "label": label, "confidence": conf, "engine": "vader"}
        except Exception:
            pass

    return {"score": 0.0, "label": "neutral", "confidence": 0.0, "engine": "none"}

# -------------------------- Utilitários de texto --------------------------

COOKIE_PATTERNS = [
    r"\bwe use cookies\b", r"\baccept cookies\b", r"\bconsent\b", r"\bprivacy policy\b",
    r"\busamos cookies\b", r"\baceitar cookies\b", r"\bconsentimento\b", r"\bpol[ií]tica de privacidade\b",
    r"\bsign in\b", r"\bsign up\b", r"\bsubscribe\b", r"\badvertisement\b"
]

def clean_text(txt: str) -> str:
    txt = re.sub(r"\s+", " ", txt or " ").strip()
    for pat in COOKIE_PATTERNS:
        txt = re.sub(pat, " ", txt, flags=re.I)
    return re.sub(r"\s{2,}", " ", txt).strip()

def looks_like_cookie_wall(text: str) -> bool:
    if not text:
        return True
    t = text.lower()
    bad_hits = sum(1 for pat in COOKIE_PATTERNS if re.search(pat, t, flags=re.I))
    return bad_hits >= 2 or ("consent" in t and "cookies" in t)

# -------------------------- Link handling --------------------------

BAD_DOMAINS = {
    "gstatic.com",
    "googleusercontent.com",
    "consent.google.com",
}

def resolve_google_news_link(link: str) -> str:
    """
    Google News RSS muitas vezes dá wrappers como:
      - news.google.com/rss/articles/... com query param ?url=REAL
      - consent.google.com/ml?continue=REAL
      - links "syndicationarticleview" (gstatic) -> ignorar
    """
    try:
        # retirar redirect do Google News normal
        if "news.google.com" in link:
            parsed = urlparse(link)
            qs = parse_qs(parsed.query)
            real = qs.get("url") or qs.get("u")
            if real:
                return unquote(real[0])

        # se for consent.google.com, extrair 'continue='
        if "consent.google.com" in link:
            parsed = urlparse(link)
            qs = parse_qs(parsed.query)
            cont = qs.get("continue")
            if cont:
                return unquote(cont[0])

        # alguns feeds devolvem ícones/recursos gstatic – descartar
        if "gstatic.com" in link or link.endswith(".png") or link.endswith(".jpg"):
            return ""
    except Exception:
        pass
    return link

# -------------------------- archive.ph --------------------------

ARCHIVE_SUBMIT = "https://archive.ph/submit/"
ARCHIVE_HOSTS = ("archive.ph", "archive.today", "archive.is")

def submit_to_archive(url: str, timeout: int = 20) -> Optional[str]:
    """
    Faz POST para archive.ph/submit e tenta descobrir o URL arquivado.
    Retorna o URL arquivado ou None.
    """
    try:
        # Algumas instâncias aceitam GET com ?url=, outras preferem POST
        resp = SESSION.post(ARCHIVE_SUBMIT, data={"url": url}, timeout=timeout, allow_redirects=True)
    except Exception:
        return None

    # 1) header Location
    loc = resp.headers.get("Location")
    if loc and any(h in loc for h in ARCHIVE_HOSTS):
        return loc

    # 2) Refresh header
    refresh = resp.headers.get("Refresh")
    if refresh:
        m = re.search(r"url=(https?://[^\s]+)", refresh, flags=re.I)
        if m:
            loc2 = m.group(1)
            if any(h in loc2 for h in ARCHIVE_HOSTS):
                return loc2

    # 3) Procurar na página um link já arquivado
    try:
        soup = BeautifulSoup(resp.text, "html.parser")
        # Alguns templates expõem um link de partilha com id SHARE_L
        cand = soup.find(id="SHARE_L")
        if cand and cand.get("href"):
            href = cand["href"]
            if any(h in href for h in ARCHIVE_HOSTS):
                return href

        # fallback: qualquer <a> que aponte para archive.*
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if any(h in href for h in ARCHIVE_HOSTS):
                return href
    except Exception:
        pass

    return None

def extract_article_text_from_url(url: str, timeout: int = 12) -> str:
    """
    Tenta extrair com Readability; se parecer cookie wall, tenta via archive.ph.
    """
    # 1) GET direto
    try:
        r = SESSION.get(url, timeout=timeout, allow_redirects=True)
        r.raise_for_status()
    except Exception:
        r = None

    def readability_extract(page_text: str) -> str:
        try:
            doc = Document(page_text)
            summary_html = doc.summary(html_partial=True)
            txt = lxml_html.fromstring(summary_html).text_content()
            return clean_text(txt)
        except Exception:
            return ""

    if r is not None:
        txt = readability_extract(r.text)
        if len(txt) > 200 and not looks_like_cookie_wall(txt):
            return txt

        # fallback para meta desc / texto bruto
        try:
            soup = BeautifulSoup(r.text, "html.parser")
            m = (soup.find("meta", attrs={"name": "description"}) or
                 soup.find("meta", attrs={"property": "og:description"}))
            if m and m.get("content"):
                desc = clean_text(m["content"])
                if len(desc) > 120 and not looks_like_cookie_wall(desc):
                    return desc
            raw = clean_text(soup.get_text(separator=" "))
            if len(raw) > 120 and not looks_like_cookie_wall(raw):
                return raw[:4000]
        except Exception:
            pass

    # 2) Se chegámos aqui, tentar archive.ph
    arch = submit_to_archive(url)
    if arch:
        try:
            ar = SESSION.get(arch, timeout=timeout, allow_redirects=True)
            if ar.status_code == 200 and ar.text:
                txt2 = readability_extract(ar.text)
                if len(txt2) > 150:
                    return txt2
                # último recurso: texto bruto
                soup2 = BeautifulSoup(ar.text, "html.parser")
                raw2 = clean_text(soup2.get_text(separator=" "))
                if len(raw2) > 150:
                    return raw2[:4000]
        except Exception:
            pass

    return ""  # não deu

# -------------------------- Pesquisar no Google News --------------------------

def google_news_search(query: str, limit: int = 12, lookback_days: int = 7, lang: str = "pt-PT") -> List[dict]:
    """
    Usa RSS do Google News. 'when:Xd' limita recência.
    'hl' controla o idioma da UI.
    """
    q = f"{query} when:{lookback_days}d"
    base = "https://news.google.com/rss/search"
    # Construção manual para não dobrar escapes
    url = f"{base}?q={quote(q)}&hl={lang}&gl=PT&ceid=PT:pt"

    parsed = feedparser.parse(url)
    items = []
    for e in parsed.entries[:limit]:
        link0 = e.get("link", "")
        link = resolve_google_news_link(link0)
        if not link:
            continue
        # filtrar domínios lixo
        ext = tldextract.extract(link)
        dom = f"{ext.domain}.{ext.suffix}".lower()
        if any(bad in dom for bad in BAD_DOMAINS):
            continue

        title = (e.get("title") or "").strip()
        published = None
        try:
            if "published_parsed" in e and e.published_parsed:
                published = datetime.fromtimestamp(time.mktime(e.published_parsed), tz=timezone.utc)
        except Exception:
            published = None

        items.append({"title": title, "url": link, "published_at": published})
    return items

# -------------------------- Peso por fonte/recência/tamanho --------------------------

def source_weight(url: str) -> float:
    ext = tldextract.extract(url)
    dom = f"{ext.domain}.{ext.suffix}".lower()
    weights = {
        "reuters.com": 1.30,
        "ft.com": 1.25,
        "bloomberg.com": 1.30,
        "barrons.com": 1.20,
        "wsj.com": 1.20,
        "seekingalpha.com": 1.05,
        "marketwatch.com": 1.05,
        "yahoo.com": 1.00,
        "investing.com": 1.00,
        "fxstreet.com": 0.95,
    }
    return weights.get(dom, 1.0)

def recency_weight(published: Optional[datetime]) -> float:
    if not published:
        return 0.9
    now = datetime.now(timezone.utc)
    dt = published.astimezone(timezone.utc)
    hours = max(0.0, (now - dt).total_seconds() / 3600.0)
    # meia-vida ~72h
    return math.exp(-hours / 72.0)

def length_weight(text: str) -> float:
    n = len(text or "")
    # saturação ~1500 chars
    return min(1.0, n / 1500.0) * 0.5 + 0.5  # 0.5..1.0

def article_weight(url: str, published: Optional[datetime], text: str) -> float:
    return source_weight(url) * recency_weight(published) * length_weight(text)

# -------------------------- Estruturas e pipeline --------------------------

@dataclasses.dataclass
class Article:
    title: str
    url: str
    published_at: Optional[str]
    text_used: str
    sentiment_score: float
    sentiment_label: str
    sentiment_confidence: float
    engine: str
    weight: float
    domain: str

def analyze_news(query: str, limit: int, lookback: int, lang: str) -> Dict[str, Any]:
    raw = google_news_search(query=query, limit=limit, lookback_days=lookback, lang=lang)

    results: List[Article] = []
    pos = neu = neg = 0
    w_sum = 0.0
    w_score = 0.0

    for e in tqdm(raw, desc="A analisar notícias"):
        url = e["url"]
        title = e["title"]
        published_dt = e["published_at"]

        body = extract_article_text_from_url(url)
        if not body:
            body = title

        # texto para sentimento: título + excerto do corpo
        text_for_sent = (title + ". " + body[:3500]).strip()
        s = score_sentiment(text_for_sent)

        # pesos
        w = article_weight(url, published_dt, body)

        # contagens discretas
        if s["label"] == "positive":
            pos += 1
        elif s["label"] == "negative":
            neg += 1
        else:
            neu += 1

        w_sum += w
        w_score += w * float(s["score"])

        ext = tldextract.extract(url)
        domain = f"{ext.domain}.{ext.suffix}".lower()

        results.append(Article(
            title=title,
            url=url,
            published_at=published_dt.isoformat() if published_dt else None,
            text_used=(title + " " + body[:1000]).strip(),
            sentiment_score=float(s["score"]),
            sentiment_label=str(s["label"]),
            sentiment_confidence=float(s["confidence"]),
            engine=s["engine"],
            weight=float(w),
            domain=domain
        ))

    avg = (w_score / w_sum) if w_sum > 0 else 0.0

    return {
        "query": query,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "model": "finbert+vader_fallback",
        "articles_count": len(results),
        "avg_sentiment_score": round(avg, 3),
        "counts": {"positive": pos, "neutral": neu, "negative": neg},
        "articles": [dataclasses.asdict(a) for a in results],
    }

# -------------------------- CLI --------------------------

def main():
    ap = argparse.ArgumentParser(description="News sentiment (FinBERT + weighted average + archive.ph)")
    ap.add_argument("--query", required=True, help='Ex.: "NVIDIA site:reuters.com OR site:ft.com"')
    ap.add_argument("--limit", type=int, default=12)
    ap.add_argument("--lookback", type=int, default=7, help="dias a recuar no Google News")
    ap.add_argument("--lang", default="pt-PT", help="hl do Google News (ex.: pt-PT, en-US)")
    args = ap.parse_args()

    data = analyze_news(args.query, args.limit, args.lookback, args.lang)

    safe = re.sub(r"[^a-zA-Z0-9\-_.]+", "_", args.query)[:80]
    out = f"news_{safe}.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    pos, neu, neg = data["counts"]["positive"], data["counts"]["neutral"], data["counts"]["negative"]
    print(f"\nOK: notícias analisadas e guardadas em {out}")
    print(f"Média ponderada de sentimento: {data['avg_sentiment_score']:.3f}  (+:{pos}  0:{neu}  -:{neg})")

if __name__ == "__main__":
    main()
