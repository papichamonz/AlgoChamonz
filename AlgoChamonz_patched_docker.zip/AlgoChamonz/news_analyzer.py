#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
news_analyzer.py — Busca notícias (Google News RSS), tenta arquivar no archive.ph,
extrai o texto, pede resumo + sentimento ao GPT e salva tudo em JSON.

USO:
  python3 news_analyzer.py --query "NVIDIA site:reuters.com OR site:ft.com OR site:barrons.com" --limit 8

Requisitos (pip):
  requests beautifulsoup4 lxml tldextract python-dateutil openai>=1.40.0 tqdm

Env:
  export OPENAI_API_KEY="sua_chave"
"""

from __future__ import annotations

import argparse
import json
import os
import re
import time
import typing as t
from datetime import datetime, timezone

import requests
from bs4 import BeautifulSoup
from dateutil import parser as dateparser
import tldextract
from urllib import parse as up
from tqdm import tqdm

# ----------------------------- Configs ---------------------------------

USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
)

HEADERS = {"User-Agent": USER_AGENT, "Accept-Language": "en-US,en;q=0.8"}

GOOGLE_NEWS_RSS = "https://news.google.com/rss/search?q={q}&hl=en-US&gl=US&ceid=US:en"

ARCHIVE_TRY_GET = "https://archive.ph/{url}"            # GET (ver se já existe snapshot)
ARCHIVE_SUBMIT = "https://archive.ph/submit/"           # POST form {url=<original>}

# Domínios que aceitamos (facilita scraping e evita clickbait)
DEFAULT_WHITELIST = {
    "reuters.com",
    "ft.com",
    "barrons.com",
    "wsj.com",
    "seekingalpha.com",
    "finance.yahoo.com",
    "bloomberg.com",
    "cnbc.com",
    "investing.com",
    "fool.com",
    "marketwatch.com",
}

# ----------------------------- Utilidades -------------------------------

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def safe_get(url: str, *, allow_redirects: bool = True, timeout: int = 15) -> requests.Response:
    return requests.get(url, headers=HEADERS, allow_redirects=allow_redirects, timeout=timeout)

def safe_post(url: str, data: dict, *, timeout: int = 30) -> requests.Response:
    return requests.post(url, headers=HEADERS, data=data, timeout=timeout, allow_redirects=True)

def domain_of(url: str) -> str:
    """Domínio registrado (<domain>.<suffix>) sem atributo depreciado."""
    try:
        ext = tldextract.extract(url)
        reg = ".".join(part for part in (ext.domain, ext.suffix) if part)
        return reg.lower() if reg else up.urlparse(url).netloc.lower()
    except Exception:
        return up.urlparse(url).netloc.lower()

def is_gstatic_or_consent(url: str) -> bool:
    host = domain_of(url)
    if "gstatic.com" in host:
        return True
    # Google consent redirect (consent.google.com / news.google.com “ml?continue=…”)
    if "consent.google.com" in host:
        return True
    return False

def clean_text(txt: str) -> str:
    txt = re.sub(r"\s+", " ", txt).strip()
    return txt

# ----------------------------- Google News ------------------------------

def fetch_google_news(query: str, limit: int = 10) -> list[dict]:
    """
    Busca no Google News (RSS). Retorna [{title, url, published_at}], filtrando
    links de redirecionamento/consent.
    """
    url = GOOGLE_NEWS_RSS.format(q=requests.utils.quote(query))
    r = safe_get(url, timeout=20)
    r.raise_for_status()

    # XML é MUITO mais estável que html.parser para RSS
    soup = BeautifulSoup(r.text, "xml")

    items: list[dict] = []
    for item in soup.find_all("item"):
        title = item.title.text if item.title else None
        link = item.link.text if item.link else None
        pub = item.pubDate.text if item.pubDate else None

        if not title or not link:
            continue

        # Google News às vezes devolve link de “news.google.com/rss/articles/…”
        # com <guid> contendo o link final. Tentamos extrair o <source> ou o
        # <link> “alternativo” dentro do conteúdo.
        # Estratégia simples: se o link tiver “news.google.com”, preferir o <source>
        if "news.google.com" in up.urlparse(link).netloc:
            # Muitos feeds incluem <source url="...">Nome</source> – tentamos puxar
            src = item.find("source")
            if src and src.get("url"):
                link = src.get("url")

        # descartar consent/google/gstatic
        if is_gstatic_or_consent(link):
            continue

        # normalizar published_at
        dt_iso = None
        if pub:
            try:
                dt_iso = dateparser.parse(pub).astimezone(timezone.utc).isoformat()
            except Exception:
                dt_iso = None

        items.append(
            {
                "title": clean_text(title),
                "url": link.strip(),
                "published_at": dt_iso,
            }
        )

        if len(items) >= limit:
            break

    return items

# ----------------------------- Archive.ph --------------------------------

def archive_lookup_or_submit(original_url: str) -> str | None:
    """
    1) Tenta GET https://archive.ph/<original_url> (se já existe snapshot).
    2) Se não, POST em https://archive.ph/submit/ com form 'url' para arquivar.
    Retorna a URL do snapshot ou None.
    """
    try:
        # 1) lookup (muitas vezes já existe)
        lookup = ARCHIVE_TRY_GET.format(url=original_url)
        r = safe_get(lookup, timeout=20)
        # Se o archive devolve a própria snapshot, r.url normalmente vira algo como
        # https://archive.ph/AbCdE (hash). Se ainda mostra a página “no results”,
        # geralmente mantem a URL com o original completo. Vamos heurística:
        if r.status_code == 200 and re.match(r"^https?://archive\.ph/[A-Za-z0-9]{4,}$", r.url):
            return r.url
    except Exception:
        pass

    # 2) submeter
    try:
        resp = safe_post(ARCHIVE_SUBMIT, data={"url": original_url}, timeout=60)
        # O archive costuma redirecionar para a snapshot; tentamos capturar resp.url
        if resp.status_code in (200, 302, 303):
            # Em muitos casos, resp.url já é a snapshot
            if re.match(r"^https?://archive\.ph/[A-Za-z0-9]{4,}$", resp.url):
                return resp.url
            # fallback: às vezes vem no body um link <a href="/AbCdE"> – tentamos extrair
            m = re.search(r'href="(https?://archive\.ph/[A-Za-z0-9]{4,})"', resp.text)
            if m:
                return m.group(1)
    except Exception:
        pass
    return None

# ----------------------------- Extractor ---------------------------------

def extract_article_text(html: str, url: str) -> str:
    """
    Extrai o corpo do texto de forma heurística. Adapta alguns domínios conhecidos.
    """
    soup = BeautifulSoup(html, "lxml")
    host = domain_of(url)

    # Remover caixas de consent/cookies comuns
    for sel in [
        "[id*=consent]", "[class*=consent]", "[class*=cookie]", "[id*=cookie]",
        "script", "style", "noscript"
    ]:
        for tag in soup.select(sel):
            tag.decompose()

    # Seletores por domínio (melhora qualidade)
    if "reuters.com" in host:
        nodes = soup.select("article, div[data-testid='StandardArticleBody_body'], div.article-body__content, div[data-testid='Body']")
    elif "ft.com" in host:
        nodes = soup.select("article, div.article__content-body, div[data-component='article-body'] p")
    elif "barrons.com" in host or "marketwatch.com" in host or "wsj.com" in host:
        nodes = soup.select("article, div#js-article__body, div.article__body, section.article__body, .articleBody p")
    else:
        # heurística genérica
        nodes = soup.select("article p, main p, .article p, [itemprop='articleBody'] p, .story-body p, .content p")

    if not nodes:
        # fallback: todos <p> razoáveis
        nodes = soup.find_all("p")

    parts: list[str] = []
    for ptag in nodes:
        txt = clean_text(ptag.get_text(" "))
        # ignorar linhas muito curtas ou com “read more”, “subscribe” etc.
        if len(txt) < 40:
            continue
        if re.search(r"(subscribe|sign in|sign-in|cookie|consent|advertisement)", txt, re.I):
            continue
        parts.append(txt)

    # se ainda ficou vazio, pega todo o texto visível
    full = " ".join(parts).strip()
    if not full:
        full = clean_text(soup.get_text(" "))

    # limitar tamanho (evitar custos e lixo)
    if len(full) > 12000:
        full = full[:12000]
    return full

# ----------------------------- OpenAI Sentimento -------------------------

def analyze_with_gpt(text: str, title: str, model: str = "gpt-4.1-mini") -> dict:
    """
    Pede um resumo curto e um sentimento (positive|neutral|negative).
    Se OPENAI_API_KEY não estiver setado, devolve neutral de forma graciosa.
    """
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return {"summary": "OpenAI API key ausente — classificado como neutro.",
                "sentiment": "neutral", "confidence": 0.4}

    # OpenAI SDK v1.x
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)

        prompt = (
            "Você é um analista financeiro. Dado o TÍTULO e o TEXTO do artigo, "
            "resuma em 2-4 frases e classifique o sentimento para investidores "
            "em uma única palavra: positive, neutral ou negative.\n\n"
            f"TÍTULO: {title}\n\nTEXTO:\n{text[:6000]}\n\n"
            "Responda em JSON com as chaves: summary, sentiment, confidence (0-1).\n"
        )

        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=280,
        )

        raw = resp.choices[0].message.content.strip()
        # Tentar parsear JSON retornado
        try:
            data = json.loads(raw)
            # sanear
            sent = str(data.get("sentiment", "neutral")).lower().strip()
            if sent not in {"positive", "neutral", "negative"}:
                sent = "neutral"
            conf = float(data.get("confidence", 0.7))
            summ = clean_text(str(data.get("summary", "")))
            return {"summary": summ, "sentiment": sent, "confidence": conf}
        except Exception:
            # fallback simples: heurística por palavras
            s = "neutral"
            if re.search(r"\b(beat|surge|record|growth|raise|strong)\b", raw, re.I):
                s = "positive"
            elif re.search(r"\b(miss|fall|drop|delay|weak|cut|ban|restrict)\b", raw, re.I):
                s = "negative"
            return {"summary": raw[:600], "sentiment": s, "confidence": 0.6}

    except Exception as e:
        return {"summary": f"Falha ao chamar OpenAI: {e}", "sentiment": "neutral", "confidence": 0.4}

def score_from_sentiment(s: str) -> int:
    if s == "positive":
        return 1
    if s == "negative":
        return -1
    return 0

# ----------------------------- Pipeline ----------------------------------

def process_articles(items: list[dict], whitelist: set[str]) -> list[dict]:
    out: list[dict] = []

    for it in tqdm(items, desc="Analisando notícias"):
        title = it["title"]
        url = it["url"]
        published_at = it.get("published_at")

        # Filtrar whitelist de domínio
        dom = domain_of(url)
        if whitelist and dom not in whitelist:
            continue

        # Tentar obter snapshot no archive.ph (opcional; pode falhar)
        archive_url = None
        try:
            archive_url = archive_lookup_or_submit(url)
        except Exception:
            archive_url = None

        # Pegar HTML “acessível” (preferir archive, senão original)
        html = None
        fetch_url = archive_url or url
        try:
            r = safe_get(fetch_url, timeout=25)
            if r.status_code == 200 and "text/html" in r.headers.get("content-type", ""):
                html = r.text
        except Exception:
            html = None

        if not html:
            # sem HTML, não dá para resumir
            out.append(
                {
                    "title": title,
                    "url": url,
                    "archive_url": archive_url,
                    "published_at": published_at,
                    "summary": "Não foi possível obter o conteúdo do artigo.",
                    "sentiment": "neutral",
                    "confidence": 0.4,
                    "word_count": 0,
                }
            )
            continue

        # Extrair texto
        text = extract_article_text(html, fetch_url)
        wc = len(text.split())

        if wc < 40:
            # se veio pouco texto (paywall duro, página errada, etc.)
            out.append(
                {
                    "title": title,
                    "url": url,
                    "archive_url": archive_url,
                    "published_at": published_at,
                    "summary": "Texto insuficiente para análise. Classificado como neutro.",
                    "sentiment": "neutral",
                    "confidence": 0.4,
                    "word_count": wc,
                }
            )
            continue

        # GPT – resumo + sentimento
        g = analyze_with_gpt(text, title, model="gpt-4.1-mini")
        out.append(
            {
                "title": title,
                "url": url,
                "archive_url": archive_url,
                "published_at": published_at,
                "summary": g.get("summary", ""),
                "sentiment": g.get("sentiment", "neutral"),
                "confidence": float(g.get("confidence", 0.7)),
                "word_count": wc,
            }
        )

        # Respeito básico à API do archive / sites
        time.sleep(0.7)

    return out

# ----------------------------- Main --------------------------------------

def main():
    ap = argparse.ArgumentParser(description="Coleta notícias e analisa sentimento com GPT.")
    ap.add_argument("--query", required=True, help='Ex.: "NVIDIA site:reuters.com OR site:ft.com"')
    ap.add_argument("--limit", type=int, default=8, help="Nº máximo de artigos (default: 8)")
    ap.add_argument(
        "--whitelist",
        type=str,
        default=",".join(sorted(DEFAULT_WHITELIST)),
        help="Lista de domínios permitidos, separados por vírgula (default: alguns sites financeiros conhecidos)",
    )
    args = ap.parse_args()

    whitelist = {d.strip().lower() for d in args.whitelist.split(",") if d.strip()}

    # 1) Buscar itens no Google News RSS
    items = fetch_google_news(args.query, limit=args.limit)

    # 2) Processar (arquivar, extrair, GPT)
    analyzed = process_articles(items, whitelist)

    # 3) Média de sentimento (-1,0,+1)
    if analyzed:
        avg = sum(score_from_sentiment(a["sentiment"]) for a in analyzed) / len(analyzed)
    else:
        avg = 0.0

    result = {
        "query": args.query,
        "generated_at": now_iso(),
        "model": "gpt-4.1-mini",
        "articles_count": len(analyzed),
        "avg_sentiment_score": round(avg, 3),
        "articles": analyzed,
    }

    # 4) Salvar JSON (nome amigável da query)
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", args.query)[:120].strip("_")
    out_fname = f"news_{safe_name}.json"
    with open(out_fname, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"✅ Notícias analisadas e salvas em {out_fname}")
    print(f"🧠 Sentiment score médio: {result['avg_sentiment_score']:.3f} "
          "(−1 negativo • 0 neutro • +1 positivo)")


if __name__ == "__main__":
    main()
