#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import dataclasses
import json
import math
import os
import re
import sys
import time
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
from urllib.parse import urlparse, parse_qs, urljoin, unquote

import requests
import feedparser
from bs4 import BeautifulSoup
from lxml import html
from readability import Document
import tldextract
from tqdm import tqdm

# -------- Sentiment backends (FinBERT -> fallback VADER) ----------
FINBERT = None
VADER = None

def _try_load_finbert():
    global FINBERT
    if FINBERT is not None:
        return FINBERT
    try:
        from transformers import AutoTokenizer, AutoModelForSequenceClassification, TextClassificationPipeline
        model_name = "ProsusAI/finbert"
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForSequenceClassification.from_pretrained(model_name)
        FINBERT = TextClassificationPipeline(model=model, tokenizer=tokenizer, top_k=None, truncation=True)
    except Exception:
        FINBERT = None
    return FINBERT

def _try_load_vader():
    global VADER
    if VADER is not None:
        return VADER
    try:
        import nltk
        from nltk.sentiment import SentimentIntensityAnalyzer
        try:
            nltk.data.find("sentiment/vader_lexicon.zip")
        except LookupError:
            nltk.download("vader_lexicon", quiet=True)
        VADER = SentimentIntensityAnalyzer()
    except Exception:
        VADER = None
    return VADER

def score_sentiment(text: str) -> Dict[str, Any]:
    """
    Returns:
      dict(score in [-1,1], label, confidence in [0,1], engine)
    """
    text = (text or "").strip()
    if not text:
        return {"score": 0.0, "label": "neutral", "confidence": 0.0, "engine": "none"}

    # Prefer FinBERT
    fb = _try_load_finbert()
    if fb is not None:
        try:
            # FinBERT prefers English; titles de PT/EN funcionam bem.
            # Truncamos para ~512 tokens via transformers (handled by pipeline)
            outputs = fb(text[:4000])
            # outputs[0] = list of dicts: [{'label':'positive','score':...}, ...]
            by_label = {d["label"].lower(): float(d["score"]) for d in outputs[0]}
            pos = by_label.get("positive", 0.0)
            neu = by_label.get("neutral", 0.0)
            neg = by_label.get("negative", 0.0)
            # Expected value in [-1,1]
            score = pos*1.0 + neu*0.0 + neg*(-1.0)
            # Most confident label
            label, conf = max(by_label.items(), key=lambda kv: kv[1])
            return {"score": score, "label": label, "confidence": conf, "engine": "finbert"}
        except Exception:
            pass

    # Fallback: VADER (lexicon-based)
    vd = _try_load_vader()
    if vd is not None:
        try:
            res = vd.polarity_scores(text[:8000])   # {'neg':..,'neu':..,'pos':..,'compound':..}
            comp = float(res.get("compound", 0.0))  # in [-1,1]
            # Rough mapping to discrete label/confidence
            if comp >= 0.05:
                label, conf = "positive", abs(comp)
            elif comp <= -0.05:
                label, conf = "negative", abs(comp)
            else:
                label, conf = "neutral", 1 - abs(comp)
            return {"score": comp, "label": label, "confidence": conf, "engine": "vader"}
        except Exception:
            pass

    return {"score": 0.0, "label": "neutral", "confidence": 0.0, "engine": "none"}

# -------------------------- Fetch & parsing --------------------------

UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": UA, "Accept-Language": "en,pt;q=0.8"})

def resolve_google_news_link(link: str) -> str:
    # Google News RSS often wraps links as news.google.com/articles/…?url=REAL
    try:
        if "news.google.com" in link:
            parsed = urlparse(link)
            qs = parse_qs(parsed.query)
            real = qs.get("url") or qs.get("u")
            if real:
                return unquote(real[0])
    except Exception:
        pass
    return link

def clean_text(txt: str) -> str:
    txt = re.sub(r"\s+", " ", txt or " ").strip()
    # remove cookie/GDPR boilerplates
    bad = [
        "accept our cookies", "we use cookies", "consent to our use of cookies",
        "subscribe", "sign in", "sign up", "advertisement"
    ]
    for b in bad:
        txt = re.sub(b, " ", txt, flags=re.I)
    return re.sub(r"\s{2,}", " ", txt).strip()

def extract_article_text(url: str, timeout: int = 10) -> str:
    try:
        r = SESSION.get(url, timeout=timeout, allow_redirects=True)
        r.raise_for_status()
    except Exception:
        return ""

    # try readability first
    try:
        doc = Document(r.text)
        summary_html = doc.summary(html_partial=True)
        txt = html.fromstring(summary_html).text_content()
        txt = clean_text(txt)
        if len(txt) > 200:
            return txt
    except Exception:
        pass

    # fallback: meta description or generic text
    try:
        soup = BeautifulSoup(r.text, "html.parser")
        # meta description
        m = soup.find("meta", attrs={"name": "description"}) or soup.find("meta", attrs={"property": "og:description"})
        if m and m.get("content"):
            desc = clean_text(m["content"])
            if len(desc) > 60:
                return desc
        # generic visible text
        txt = clean_text(soup.get_text(separator=" "))
        return txt[:4000]
    except Exception:
        return ""

def source_weight(url: str) -> float:
    ext = tldextract.extract(url)
    dom = f"{ext.domain}.{ext.suffix}".lower()
    # tune weights (can extend freely)
    weights = {
        "reuters.com": 1.25,
        "ft.com": 1.20,
        "bloomberg.com": 1.25,
        "barrons.com": 1.15,
        "wsj.com": 1.20,
        "seekingalpha.com": 1.05,
        "marketwatch.com": 1.05,
        "yahoo.com": 1.00,
        "investing.com": 1.00,
        "fxstreet.com": 0.95,
    }
    return weights.get(dom, 1.0)

def recency_weight(published: Optional[datetime]) -> float:
    if not published:
        return 0.9
    now = datetime.now(timezone.utc)
    dt = published.astimezone(timezone.utc)
    hours = max(0.0, (now - dt).total_seconds() / 3600.0)
    # 50% weight loss a cada ~72h
    return math.exp(-hours / 72.0)

def length_weight(text: str) -> float:
    n = len(text or "")
    # saturate around 1500 chars
    return min(1.0, n / 1500.0) * 0.5 + 0.5  # 0.5..1.0

def article_weight(url: str, published: Optional[datetime], text: str) -> float:
    return source_weight(url) * recency_weight(published) * length_weight(text)

# -------------------------- Google News --------------------------

def google_news_search(query: str, limit: int = 12, lookback_days: int = 7, lang: str = "pt-PT") -> List[dict]:
    # Google News RSS
    # when:Xd limita a recência; hl controla idioma da UI
    q = f"{query} when:{lookback_days}d"
    base = "https://news.google.com/rss/search"
    params = {"q": q, "hl": lang, "gl": "PT", "ceid": "PT:pt"}
    url = f"{base}?q={requests.utils.quote(q)}&hl={lang}&gl=PT&ceid=PT:pt"

    parsed = feedparser.parse(url)
    items = []
    for e in parsed.entries[:limit]:
        link0 = e.get("link", "")
        link = resolve_google_news_link(link0)
        title = e.get("title", "").strip()
        # published
        published = None
        try:
            if "published_parsed" in e and e.published_parsed:
                published = datetime.fromtimestamp(time.mktime(e.published_parsed), tz=timezone.utc)
        except Exception:
            published = None
        items.append({"title": title, "url": link, "published_at": published})
    return items

# -------------------------- Main flow --------------------------

@dataclasses.dataclass
class Article:
    title: str
    url: str
    published_at: Optional[str]
    text_used: str
    sentiment_score: float
    sentiment_label: str
    sentiment_confidence: float
    engine: str
    weight: float
    domain: str

def analyze_news(query: str, limit: int, lookback: int, lang: str) -> Dict[str, Any]:
    raw = google_news_search(query=query, limit=limit, lookback_days=lookback, lang=lang)

    results: List[Article] = []
    pos = neu = neg = 0
    w_sum = 0.0
    w_score = 0.0

    for e in tqdm(raw, desc="Analisando notícias"):
        url = e["url"]
        title = e["title"]
        published_dt = e["published_at"]

        body = extract_article_text(url)
        if not body:
            body = title

        # texto a classificar: título + excerto do corpo
        text_for_sent = (title + ". " + body[:3500]).strip()
        s = score_sentiment(text_for_sent)

        # pesos
        w = article_weight(url, published_dt, body)

        # contagens discretas
        if s["label"] == "positive":
            pos += 1
        elif s["label"] == "negative":
            neg += 1
        else:
            neu += 1

        w_sum += w
        w_score += w * float(s["score"])

        ext = tldextract.extract(url)
        domain = f"{ext.domain}.{ext.suffix}".lower()

        results.append(Article(
            title=title,
            url=url,
            published_at=published_dt.isoformat() if published_dt else None,
            text_used=(title + " " + body[:1000]).strip(),
            sentiment_score=float(s["score"]),
            sentiment_label=str(s["label"]),
            sentiment_confidence=float(s["confidence"]),
            engine=s["engine"],
            weight=float(w),
            domain=domain
        ))

    avg = (w_score / w_sum) if w_sum > 0 else 0.0

    return {
        "query": query,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "model": "finbert+vader_fallback",
        "articles_count": len(results),
        "avg_sentiment_score": round(avg, 3),
        "counts": {"positive": pos, "neutral": neu, "negative": neg},
        "articles": [dataclasses.asdict(a) for a in results],
    }

def main():
    ap = argparse.ArgumentParser(description="News sentiment (FinBERT + weighted average)")
    ap.add_argument("--query", required=True, help='Ex.: "NVIDIA site:reuters.com OR site:ft.com"')
    ap.add_argument("--limit", type=int, default=12)
    ap.add_argument("--lookback", type=int, default=7, help="dias")
    ap.add_argument("--lang", default="pt-PT", help="hl para Google News (ex.: pt-PT, en-US)")
    args = ap.parse_args()

    data = analyze_news(args.query, args.limit, args.lookback, args.lang)

    # nome do arquivo mais curto
    safe = re.sub(r"[^a-zA-Z0-9\-_.]+", "_", args.query)[:80]
    out = f"news_{safe}.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    pos, neu, neg = data["counts"]["positive"], data["counts"]["neutral"], data["counts"]["negative"]
    print(f"\n☑ Notícias analisadas e salvas em {out}")
    print(f"🧮 Sentiment score médio (ponderado): {data['avg_sentiment_score']:.3f} "
          f"(+:{pos} • 0:{neu} • -:{neg})")

if __name__ == "__main__":
    main()
