#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
import pandas as pd

from phase3_consolidator import (
    download_data, compute_indicators, fetch_fundamentals, fetch_news_summary,
    build_phase3_payload
)

app = FastAPI(title="ALGO Backend", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/api/phase3")
def api_phase3(
    ticker: str = Query("AAPL"),
    period: str = Query("6mo"),
    interval: str = Query("1d"),
    news_query: Optional[str] = Query(None),
    news_limit: int = Query(10, ge=1, le=50),
    lookback: int = Query(7, ge=1, le=30),
    lang: str = Query("pt-PT")
):
    df = download_data(ticker, period, interval)
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [c[0] for c in df.columns]
    df = df.dropna()
    df = compute_indicators(df)

    fundamentals = fetch_fundamentals(ticker)
    news_summary = fetch_news_summary(news_query or ticker, news_limit, lookback, lang)
    payload = build_phase3_payload(ticker, df, news_summary, fundamentals)
    return payload
