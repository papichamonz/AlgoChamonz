#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Phase 3 – Consolidation (API-ready)
Corrige:
- MultiIndex de colunas do yfinance (Close vira DataFrame).
- Séries Bollinger calculadas com Series 1D.
- Exporta séries no formato do Lightweight Charts.
"""
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import yfinance as yf

# ---------------- Utils: normalização OHLCV ----------------

def _pick_series(obj: pd.DataFrame | pd.Series, ticker: Optional[str] = None) -> pd.Series:
    """Se vier DataFrame (ex.: multi-ticker), escolhe a coluna do ticker ou a primeira."""
    if isinstance(obj, pd.Series):
        return obj
    if ticker and ticker in obj.columns:
        return obj[ticker]
    # escolhe a 1ª coluna disponível
    return obj.iloc[:, 0]

def normalize_ohlcv(df: pd.DataFrame, ticker: Optional[str] = None) -> pd.DataFrame:
    """
    Normaliza DataFrame vindo do yfinance para colunas simples: Open, High, Low, Close, Volume.
    Lida com casos de MultiIndex (nível 0='Open'.., nível 1=ticker).
    """
    if not isinstance(df, pd.DataFrame) or df.empty:
        raise RuntimeError("Sem dados de preço.")

    if not isinstance(df.columns, pd.MultiIndex):
        # já está simples
        out = df.copy()
    else:
        cols = df.columns
        lvl0 = cols.get_level_values(0)
        # tentar por nível 0
        pieces = {}
        for name in ["Open", "High", "Low", "Close", "Adj Close", "Volume"]:
            if name in lvl0:
                sub = df.xs(name, axis=1, level=0, drop_level=False)
                pieces[name] = _pick_series(sub.droplevel(0, axis=1), ticker)
        out = pd.DataFrame({k: v for k, v in pieces.items() if k in pieces})

    # coerção para numérico (ignora strings como 'AAPL')
    for c in ["Open", "High", "Low", "Close", "Adj Close", "Volume"]:
        if c in out.columns:
            out[c] = pd.to_numeric(out[c], errors="coerce")

    # preferir 'Close' normal; manter apenas colunas chave
    keep = [c for c in ["Open", "High", "Low", "Close", "Volume"] if c in out.columns]
    out = out[keep].dropna(how="any")
    # index limpo (sem tz)
    try:
        out.index = pd.to_datetime(out.index).tz_localize(None)
    except Exception:
        pass
    return out

# ---------------- Indicadores ----------------

def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = (delta.clip(lower=0)).rolling(window=period).mean()
    loss = (-delta.clip(upper=0)).rolling(window=period).mean()
    rs = gain / (loss.replace(0, np.nan))
    out = 100 - (100 / (1 + rs))
    return out.bfill().fillna(50.0)

def ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()

def macd(series: pd.Series, fast=12, slow=26, signal=9):
    m = ema(series, fast) - ema(series, slow)
    s = ema(m, signal)
    h = m - s
    return m, s, h

def compute_indicators(df: pd.DataFrame) -> pd.DataFrame:
    close = pd.to_numeric(df["Close"], errors="coerce").astype(float)
    df["RSI14"] = rsi(close, 14)
    df["SMA20"] = close.rolling(20).mean()
    df["SMA50"] = close.rolling(50).mean()
    m, s, h = macd(close)
    df["MACD"], df["MACD_SIGNAL"], df["MACD_HIST"] = m, s, h

    mid = close.rolling(20).mean()
    std = close.rolling(20).std()
    df["BOLL_MID"] = mid
    df["BOLL_UPPER"] = mid + 2 * std
    df["BOLL_LOWER"] = mid - 2 * std
    return df

# ---------------- Suporte / Resistência ----------------

def compute_support_resistance(df: pd.DataFrame, lookback=20, levels=3) -> Dict[str, List[float]]:
    if len(df) == 0:
        return {"supports": [], "resistances": []}
    window = df.tail(lookback)
    lows = pd.to_numeric(window["Low"], errors="coerce").dropna().to_numpy()
    highs = pd.to_numeric(window["High"], errors="coerce").dropna().to_numpy()
    supports = sorted(set(lows.tolist()))[:levels]
    resistances = sorted(set(highs.tolist()), reverse=True)[:levels]
    return {"supports": [float(x) for x in supports], "resistances": [float(x) for x in resistances]}

# ---------------- Fundamentos ----------------

def fetch_fundamentals(ticker: str) -> Dict[str, Any]:
    t = yf.Ticker(ticker)
    info = {}
    try:
        info = t.info or {}
    except Exception:
        pass
    return {"market_cap": info.get("marketCap"), "currency": info.get("currency")}

# ---------------- Notícias (stub) ----------------

@dataclass
class NewsSummary:
    avg_sentiment_score: Optional[float]
    counts: Dict[str, int]

def fetch_news_summary(query: Optional[str], limit: int, lookback: int, lang: str) -> NewsSummary:
    return NewsSummary(avg_sentiment_score=None, counts={"positive": 0, "neutral": 0, "negative": 0})

# ---------------- Download ----------------

def download_data(ticker: str, period="6mo", interval="1d") -> pd.DataFrame:
    """
    Usa group_by='column' para evitar MultiIndex; se ainda vier MultiIndex, normaliza.
    """
    df = yf.download(
        tickers=ticker,
        period=period,
        interval=interval,
        progress=False,
        auto_adjust=False,
        group_by="column",
    )
    if df is None or len(df) == 0:
        raise RuntimeError("Falha ao baixar dados de preço.")
    try:
        df = normalize_ohlcv(df, ticker=ticker)
    except Exception:
        # fallback best-effort
        pass
    return df.dropna()

# ---------------- Payload para Lightweight Charts ----------------

def lwc_series_payload(df: pd.DataFrame, include_indicators=True) -> Dict[str, Any]:
    ts = (pd.to_datetime(df.index).astype("int64") // 10**9).astype(int).tolist()
    o = df["Open"].astype(float).tolist()
    h = df["High"].astype(float).tolist()
    l = df["Low"].astype(float).tolist()
    c = df["Close"].astype(float).tolist()
    ohlc = [{"time": t, "open": oo, "high": hh, "low": ll, "close": cc}
            for t, oo, hh, ll, cc in zip(ts, o, h, l, c)]
    out: Dict[str, Any] = {"ohlc": ohlc}

    if include_indicators:
        def _line(series: pd.Series):
            s = pd.to_numeric(series, errors="coerce").dropna()
            ts_s = (pd.to_datetime(s.index).astype("int64") // 10**9).astype(int).tolist()
            return [{"time": t, "value": float(v)} for t, v in zip(ts_s, s.tolist())]

        for col in ["SMA20", "SMA50", "BOLL_MID", "BOLL_UPPER", "BOLL_LOWER"]:
            if col in df.columns:
                out[col] = _line(df[col])
    return out

# ---------------- Consolidado ----------------

def build_phase3_payload(ticker: str, df: pd.DataFrame, news: NewsSummary, fundamentals: Dict[str, Any]) -> Dict[str, Any]:
    last = df.iloc[-1]
    tech = {
        "close": float(last["Close"]),
        "rsi14": float(last["RSI14"]),
        "sma20": float(last["SMA20"]),
        "sma50": float(last["SMA50"]),
        "macd_hist": float(last["MACD_HIST"]),
        "support_resistance": compute_support_resistance(df),
    }
    return {
        "ticker": ticker,
        "technical": tech,
        "fundamentals": fundamentals,
        "news": news.__dict__,
    }
